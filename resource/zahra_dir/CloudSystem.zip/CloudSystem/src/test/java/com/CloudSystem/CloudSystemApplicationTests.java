package com.CloudSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
